import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from joblib import dump

# Example dataset (replace with your actual dataset)
data = {
    'url': [
        'br-icloud.com.br',
        'mp3raid.com/music/krizz_kaliko.html',
        'http://www.garage-pirenne.be/index.php?option=com_content&view=article&id=70&vsig70_0=15',
        'https://docs.google.com/spreadsheet/viewform?formkey=dGg2Z1lCUHlSdjllTVNRUW50TFIzSkE6MQ'
    ],
    'type': [
        'phishing',
        'benign',
        'defacement',
        'phishing'
    ]
}

df = pd.DataFrame(data)

# Feature extraction using TF-IDF
vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(df['url'])

# Model training
model = LogisticRegression(max_iter=1000)
model.fit(X, df['type'])

# Save the model
dump(model, 'model.joblib')
# Save the TF-IDF vectorizer
dump(vectorizer, 'vectorizer.joblib')

print("Model and vectorizer saved successfully.")
