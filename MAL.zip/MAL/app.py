from flask import Flask, render_template, request, jsonify
from joblib import load
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.exceptions import NotFittedError

app = Flask(__name__)

# Load the model and vectorizer
model = load('model.joblib')
vectorizer = load('vectorizer.joblib')

def predict_url_type(url):
    try:
        # Transform the input URL using the loaded vectorizer
        X = vectorizer.transform([url])

        # Perform prediction using your model
        prediction = model.predict(X)
        return prediction[0]

    except NotFittedError as e:
        print(f"Vectorizer or Model not fitted. Error: {e}")
        return "Error: Model not fitted."

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        url = request.json['url']
        prediction = predict_url_type(url)
        return jsonify({'url': url, 'prediction': prediction}), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
