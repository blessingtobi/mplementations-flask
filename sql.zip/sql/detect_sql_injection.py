# detect_sql_injection.py

def detect_sql_injection(sql_query):
    # Define patterns indicative of SQL injection
    malicious_patterns = ['UNION SELECT', 'OR 1=1', '--']

    # Convert input query to uppercase for case insensitivity
    query_upper = sql_query.upper()

    # Check for malicious patterns
    for pattern in malicious_patterns:
        if pattern in query_upper:
            return "Malicious"

    return "Non-malicious"
