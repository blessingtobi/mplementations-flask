# app.py

from flask import Flask, render_template, request

from detect_sql_injection import detect_sql_injection

app = Flask(__name__)

# Routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    if request.method == 'POST':
        sql_query = request.form['sql_query']

        # Detect SQL injection
        result = detect_sql_injection(sql_query)

        return render_template('index.html', prediction=result, sql_query=sql_query)

@app.route('/batch_test')
def batch_test():
    # Example batch queries (you can modify as needed)
    batch_queries = [
        "SELECT * FROM users WHERE id = 1;",
        "SELECT name, email FROM users WHERE id = 10;",
        "INSERT INTO users (name, email, age) VALUES ('John Doe', 'john@example.com', 25);",
        "SELECT * FROM users WHERE id = 1 OR 1=1;",
        "SELECT * FROM users WHERE id = 1 UNION SELECT username, password FROM admin_users;",
        "SELECT * FROM users WHERE username = 'admin' -- AND password = 'password';"
    ]

    results = []
    for query in batch_queries:
        result = detect_sql_injection(query)
        results.append((query, result))

    return render_template('batch_test.html', results=results)

if __name__ == '__main__':
    app.run(debug=True)
