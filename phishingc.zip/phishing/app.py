from flask import Flask, render_template, request
import pandas as pd
import pickle

app = Flask(__name__)

# Load the trained model
with open('random_forest_model.pkl', 'rb') as model_file:
    model = pickle.load(model_file)

# Example data
emails = pd.DataFrame({
    'email_id': [12345, 12346],
    'sender': ['phishing@example.com', 'legit@example.com'],
    'subject': ['Urgent! Update Your Account', 'Monthly Report'],
    'received': ['2024-07-14', '2024-07-14'],
    'risk_score': ['High', 'Low'],
    'quarantined': [True, False],
    'notified': [True, False]
})

@app.route('/')
def dashboard():
    summary = {
        'total_emails': len(emails),
        'phishing_emails': emails[emails['risk_score'] == 'High'].shape[0],
        'legit_emails': emails[emails['risk_score'] == 'Low'].shape[0],
        'quarantined_emails': emails[emails['quarantined'] == True].shape[0]
    }
    return render_template('dashboard.html', summary=summary, emails=emails.to_dict('records'))

@app.route('/email/<int:email_id>')
def email_analysis(email_id):
    email = emails[emails['email_id'] == email_id].iloc[0]
    return render_template('email_analysis.html', email=email)

@app.route('/settings')
def settings():
    return render_template('settings.html')

@app.route('/check_email', methods=['GET', 'POST'])
def check_email():
    result = None
    if request.method == 'POST':
        sender = request.form['sender']
        subject = request.form['subject']
        body = request.form['body']
        
        # Feature extraction
        subject_len = len(subject)
        body_len = len(body)
        
        # Create a DataFrame for the input email
        input_data = pd.DataFrame([[subject_len, body_len]], columns=['subject_len', 'body_len'])
        
        # Predict using the loaded model
        prediction = model.predict(input_data)[0]
        result = 'Phishing' if prediction == 1 else 'Legitimate'
    
    return render_template('check_email.html', result=result)

if __name__ == '__main__':
    app.run(debug=True)
