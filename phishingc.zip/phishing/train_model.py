import pandas as pd
from sklearn.ensemble import RandomForestClassifier
import pickle

# Example dataset
data = {
    'sender': ['phishing@example.com', 'legit@example.com', 'phishing@fake.com', 'legit@real.com'],
    'subject': ['Urgent! Update Your Account', 'Monthly Report', 'Verify Your Account', 'Team Meeting'],
    'body': ['Click here to update', 'Please find the report attached', 'Your account is at risk', 'Meeting scheduled at 3 PM'],
    'label': [1, 0, 1, 0]  # 1 for phishing, 0 for legitimate
}

# Convert to DataFrame
df = pd.DataFrame(data)

# Feature extraction (simple example)
df['subject_len'] = df['subject'].apply(len)
df['body_len'] = df['body'].apply(len)

# Features and labels
X = df[['subject_len', 'body_len']]
y = df['label']

# Train the Random Forest model
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X, y)

# Save the model
with open('random_forest_model.pkl', 'wb') as model_file:
    pickle.dump(model, model_file)
